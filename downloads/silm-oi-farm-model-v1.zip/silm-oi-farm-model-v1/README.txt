silm_oi - ready-made recognition model of the UAV SILM project
Finds: tractor, car, truck, livestock. YOLO11n, 320x320 input, TFLite (INT8 body, float head).
Trained on Google Open Images photos (boxes CC BY 4.0, photos CC BY 2.0 by their Flickr authors).
Mostly ground-level photos: from straight above it recognises much less. Measured results:
https://github.com/rometlehari-maker/uav-silm/blob/c59aee6a7816e40cd161e910490e644d6fcc6469/onboard/training/README.md

Licence: AGPL-3.0 (derived from Ultralytics YOLO11n, (c) Ultralytics), see LICENSE-silm_oi-AGPL-3.0.txt.
Corresponding source (how it was made): onboard/training/ in
https://github.com/rometlehari-maker/uav-silm/tree/c59aee6a7816e40cd161e910490e644d6fcc6469/onboard/training
Built from commit c59aee6a7816e40cd161e910490e644d6fcc6469 (2026-11-08).
