silm_oi - ready-made recognition model of the UAV SILM project
Finds: tractor, car, truck, livestock. YOLO11n, 320x320 input, TFLite (INT8 body, float head).
Trained on Google Open Images photos (boxes CC BY 4.0, photos CC BY 2.0 by their Flickr authors).
Mostly ground-level photos: from straight above it recognises much less. Measured results:
https://github.com/rometlehari-maker/uav-silm/blob/b7315256a69dc4cbe3115e86b3159d4185e80ed8/onboard/training/README.md

Licence: AGPL-3.0 (derived from Ultralytics YOLO11n, (c) Ultralytics), see LICENSE-silm_oi-AGPL-3.0.txt.
Corresponding source (how it was made): onboard/training/ in
https://github.com/rometlehari-maker/uav-silm/tree/b7315256a69dc4cbe3115e86b3159d4185e80ed8/onboard/training
Built from commit b7315256a69dc4cbe3115e86b3159d4185e80ed8 (2026-11-08).
